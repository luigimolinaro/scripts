#!/bin/bash
filePath="test/setup/env_auto_setup"
function usage() {
    echo "Usage:"
    echo "---------------------------------"
    echo "If you have already logged into oc, then execute the following command: "
    echo "./install-legacy-migration-config-spec.sh -url <ocp-url> -n <namespace>"
    echo "---------------------------------"
    echo "If you have token from a valid user session, then execute the following command: "
    echo "./install-legacy-migration-config-spec.sh -t <ocp-token> -url <ocp-url> -n <namespace>"
    echo "---------------------------------"
    echo "If you have username and password for oc login, then execute the following command: "
    echo "./install-legacy-migration-config-spec.sh -u <ocp-username> -p <ocp-password> -url <ocp-url> -n <namespace>"
    echo "---------------------------------"
    echo "Mandatory arguments:"
    echo "-url or --url                  Specify the OCP URL"
    echo "-n or --nameSpace              Specify the OCP namespace"
    echo "Optional arguments:"
    echo "-t | --token                   Specify the OCP token"
    echo "-u | --username                Specify the OCP username"
    echo "-p | --password                Specify the OCP password"
}

function ocpLogin() {
    if [ -n "$username" ] && [ -n "$password" ] && [ -n "$ocpServer" ] && [ -n "$nameSpace" ]; then
        oc login "$ocpServer" --insecure-skip-tls-verify -u "$username" -p "$password"
    elif [ -n "$ocpServer" ] && [ -n "$token" ] && [ -n "$nameSpace" ]; then
        oc login --token "$token" --server "$ocpServer"
    elif [ -n "$ocpServer" ] && [ -n "$nameSpace" ]; then
        cmd="oc whoami --show-token=true"
        token=$(eval "$cmd")
        oc login --token "$token" --server "$ocpServer"
    else
        usage
        exit 0
    fi
    if [[ $? -ne 0 ]]; then
        usage
        exit 0
    fi
    oc project "$nameSpace"
}

function deleteConfigMapIfExists() {
  local configMapName="$1"
  oc get configmap -n ${nameSpace} | grep "$configMapName"
  if [ $(echo $?) -eq 0 ]; then
    echo "[INFO] Previous $configMapName exist, deleting it to apply the new one"
    oc delete configmap "$configMapName" -n ${nameSpace}
  else
    echo "[INFO] $configMapName is not previously installed, applying it"
  fi
}

function createConfigMap() {
    local configMapName="$1"

    oc create -f "$configMapName.yaml" -n ${nameSpace}

    #check result
    oc get configmap -n ${nameSpace} | grep "$configMapName"
    if [ $(echo $?) -eq 0 ]; then
      echo "[INFO] $configMapName created"
    else
      echo "[ERROR] Failed to create $configMapName"
      exit 1
    fi
}

function applyPatch() {
  # This is the official way to create legacy-migration-aux-exim-cm in 4.6.x, will be also be used by customer
  # Need update the legacy-migration-aux-exim-cm.yaml under the path for source control if later yaml file has changes.

  wkc_cr_uid=$(oc get wkc wkc-cr -n ${nameSpace} -o yaml | awk '/^  uid:/ {printf "uid: %s", $2}' | tr -d '\n')
  wkc_version=$(oc get wkc wkc-cr -n ${nameSpace} | grep wkc-cr | awk '{print $2}')

  # check if legacy-user-role-extensions already deployed, if yes delete it first
  deleteConfigMapIfExists "legacy-user-role-extensions"

  # apply the new one
  echo "[INFO] Create legacy-user-role-extensions.yaml"
  sed "s/<PRODUCT_VERSION>/${wkc_version}/g" legacy-user-role-extensions-TEMPLATE.yaml > legacy-user-role-extensions.yaml
  sed -i "s/namespace: <NAMESPACE>/namespace: ${nameSpace}/g" legacy-user-role-extensions.yaml
  createConfigMap "legacy-user-role-extensions"

  # check if legacy-migration-aux-exim-cm already deployed, if yes delete it first
  deleteConfigMapIfExists "legacy-migration-aux-exim-cm"

  #apply the new one
  # Replace the wkc-cr uid value in legacy-migration-aux-exim-cm.yaml
  sed "s/uid: <UID>/${wkc_cr_uid}/g" legacy-migration-aux-exim-cm-TEMPLATE-PROD.yaml > legacy-migration-aux-exim-cm.yaml
  # Set the namespace
  sed -i "s/namespace: <NAMESPACE>/namespace: ${nameSpace}/g" legacy-migration-aux-exim-cm.yaml

  createConfigMap "legacy-migration-aux-exim-cm"
}

#=====================Start Set Up ===========================
if [[ $# == 0 ]];then
    usage
    exit 0
fi

while (( $# > 0 ));do
    case "$1" in
        -t | --token )
            token="$2"
            shift 2
            ;;
         -u | --username )
            username="$2"
            shift 2
            ;;
         -p | --password)
            password="$2"
            shift 2
            ;;
         -n | --namespace)
            nameSpace="$2"
            shift 2
            ;;
        -url | --url )
            ocpServer="$2"
            shift 2
            ;;
        -h | --help )
            usage
            exit 0
            ;;
        *)
            usage
	    exit 0
	    ;;
    esac
done

ocpLogin
applyPatch